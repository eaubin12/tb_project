Module global_params
  complex(kind=8), parameter :: ci = (0.d0, 1.d0)
  integer, parameter :: num_gamma_Q = 8,l_max = 4
  real*8 pi,ryd,au_eV,au_cm,au_to_sec,el_energy_Q1
  integer num_Q,num_v, dim_lm,num_ev,num_scatE,num_elec
  integer, allocatable, dimension(:,:) ::  qn_ev
  integer, allocatable, dimension(:,:,:) :: qnums_Q
  integer, allocatable, dimension(:,:,:,:) :: qn_map
  real(kind=8), allocatable, dimension(:) ::  geom,energies_ev,E_el_Rmat,energies_v
  Complex*16, allocatable, dimension(:,:,:,:) :: S_Q
  complex*16, allocatable, dimension(:,:,:) :: S_ev

End Module global_params
!---------------------------------------------------
program cross_section_pr
  Use global_params
  implicit none
  
  pi=atan(1.d0)*4.d0
  Ryd=219474.6313710d0
  au_eV=27.2113834d0
  au_cm=0.5291772083d-8
  au_to_sec=2.4188843d-17 

  num_Q=1! -real number of geometires!!!! ! number of geometries
  num_v= 1; If(num_Q==1)num_v= 1
  Call reading_R_matrix_data
  call basis_change_lm
  call vibr_FT
  Call  Calc_differential_XS
  call Calc_integral_XS;  stop 'ok'
  call vibr_ex_cross_sections
  deallocate(E_el_Rmat,S_Q,geom,qn_ev,energies_ev,S_ev,energies_v,qnums_Q,qn_map)
end program cross_section_pr
! ****************************************************************

!  *****      cross section    ***********

! ****************************************************************
Subroutine vibr_ex_cross_sections
  Use global_params
  implicit none
  integer i,nE,ie,n_c,n_o
  Real*8 dE,E_end,E_begin,P_exc_FT(num_v,num_v),P_exc(num_v,num_v),Sigma(num_v,num_v),E
  Complex*16 tmpc
  
  E_begin=energies_ev(1)
  E_end=E_begin+E_el_Rmat(num_scatE)
  nE=1000
  dE=(E_end-E_begin)/nE
!   open(91,file='P_exc_FT.dat')
!   open(92,file='P_exc.dat')
  open(91,file='P_exc_chan_eliminat.bin',form='unformatted')
  write(91)num_v,nE
  write(91)pi,ryd,au_eV,au_cm,au_to_sec,E_end,E_begin
  write(91)energies_v(1:num_v)
  
  open(92,file='P_exc_no_chan_elimi.bin',   form='unformatted')
  write(92)num_v,nE
  write(92)pi,ryd,au_eV,au_cm,au_to_sec,E_end,E_begin
  write(92)energies_v(1:num_v)
  
  Do ie=1,nE
    E=E_begin+ie*dE
    Call Time_delay_S(E,P_exc_FT,P_exc,n_o)

    Write(91)E,P_exc_FT
    Write(92)E,P_exc

  Enddo
  Close(91);Close(92)
End Subroutine vibr_ex_cross_sections
! *********************************************************
 Subroutine Time_delay_S(E,P_exc_FT,P_exc,n_o)
!  E - total energy
   Use global_params
   Integer n_o,n_o_deter,n_c,i,ie,j
   Real*8 E,delt,P_exc_FT(num_v,num_v),P_exc(num_v,num_v),E_el
   Complex*16 S_int(num_ev,num_ev)
   Complex*16, allocatable ::  beta(:),T_phys(:,:)
   n_o=n_o_deter(E,num_ev,energies_ev)
   n_c=num_ev-n_o
   Allocate(T_phys(n_o,n_o),beta(num_ev))
   beta=0.d0
   Do i=1,n_c
     If(energies_ev(i+n_o)-E<0.)Then
       Print *,n_o,i,energies_ev(i+n_o),E
       Stop 'E_ion-E<0, point 1'
     Endif
     beta(i+n_o)=pi/sqrt(2.d0*(energies_ev(i+n_o)-E))
   Enddo
   !determination of the ie index (energy of the smooth S-matrix)
   E_el=E-(energies_ev(n_o)+energies_ev(1))/2.
   Do ie=1,num_scatE-1
     If(E_el<E_el_Rmat(ie))exit
   Enddo
   call s_matrix_interpolation(ie,E_el,S_int)
!   Call Calc_T_phys(num_ev,n_o,beta,S_ev(:,:,ie),T_phys(1:n_o,1:n_o))
   Call Calc_T_phys(num_ev,n_o,beta,S_int,T_phys(1:n_o,1:n_o))
   
!    Do i=1,n_o
!      Write(40,'(100e12.4)')T_phys(i,1:n_o)
!    Enddo
   P_exc_FT=0.d0;P_exc=0.d0;
   
   Do i=1,num_ev;Do j=1,num_ev
     If(energies_ev(i)<E .and. energies_ev(j)<E)then
       P_exc_FT(qn_ev(1,i),qn_ev(1,j))=P_exc_FT(qn_ev(1,i),qn_ev(1,j))+abs(T_phys(i,j))**2
       P_exc(qn_ev(1,i),qn_ev(1,j))=P_exc(qn_ev(1,i),qn_ev(1,j))+abs(S_int(i,j))**2
     Endif
   Enddo;Enddo
   
   Deallocate(T_phys,beta)
 End Subroutine Time_delay_S
!---------------------------------------------------
Subroutine s_matrix_interpolation(ie,E,S_int)
  Use global_params
  implicit none
  Integer ie,i
  Real*8 n,g,deltaE,E
  Complex*16 S_int(num_ev,num_ev)
  
  n=0.d0
  S_int=(0.d0,0.d0)
  deltaE=E_el_Rmat(2)-E_el_Rmat(1)
  Do i=max(1,ie-3),min(num_scatE,ie+2)
    g=exp(-((   (E-E_el_Rmat(i)) /deltaE )**2))
    S_int=S_int+S_ev(:,:,i)*g
    n=n+g
  Enddo
  S_int=S_int/n
End Subroutine s_matrix_interpolation
!---------------------------------------------------
Subroutine vibr_FT
  Use global_params
  implicit none
  integer i_ev,iv,i,i_e,j_e,ie,j,i_Q
  Real*8 dQ(num_Q),norm,upper,lower
  Complex*16 wf_on_geom(num_v,num_Q),wfi,wfj
  
  Allocate(energies_v(num_v))
  ! wave functions

  If(num_Q==1)Then
    wf_on_geom=1.d0
    dQ(1)=1.
    energies_v(1)=el_energy_Q1
  Else
    wf_on_geom=0.d0
    call Program_of_LAC(num_Q,num_v,geom,energies_v,wf_on_geom)
    print *,'energies_v=',energies_v
    dQ(1)=geom(2)-geom(1);dQ(num_Q)=geom(num_Q)-geom(num_Q-1)
    Do i_Q=2,num_Q-1
      dQ(i_Q)=(geom(i_Q+1)-geom(i_Q-1))/2.d0
    Enddo

!   Do i=1,num_Q
!     lower=-100.d0
!     upper=100.d0
!     Do j=1,num_Q
!       If(i .ne. j)then
!         if(abs(geom(j)-geom(i))<1.e-6)stop 'two identical geometries'
!         
!         If(abs(geom(i)-geom(j))<(geom(i)-lower) .and. geom(j)<geom(i))lower=geom(j)
!         If(abs(geom(i)-geom(j))<(upper-geom(i)) .and. geom(j)>geom(i))upper=geom(j)
!       Endif
!     Enddo
!     If(lower==-100.d0)lower=2.d0*geom(i)-upper
!     If(upper==100.d0)upper=2.d0*geom(i)-lower
!     dQ(i)=(upper-lower)/2.d0
!   Enddo
  
  
  ! renormalization of wfs
    Do iv=1,num_v
      norm=0.d0
      Do i_Q=1,num_Q
        norm=norm+abs(wf_on_geom(iv,i_Q))**2*dQ(i_Q)
      Enddo
      print *,'norm=',norm
      wf_on_geom(iv,:)=wf_on_geom(iv,:)/sqrt(norm)
    Enddo
  Endif
  Write(6,'(A,100e12.4)')'geom(:)=',geom(1:num_Q)
  Write(6,'(A,100e12.4)')'wf_on_geom(1,:)=',real(wf_on_geom(1,:))
  !   vib FT
  !   energies and quantum numbers
  num_ev=num_v*dim_lm
  allocate(qn_ev(5,num_ev),energies_ev(num_ev),qn_map(num_v,num_elec,0:l_max,-l_max:l_max))
  qn_map=0
  i_ev=0
  Do iv=1,num_v
    Do i=1,dim_lm
      i_ev=i_ev+1
      qn_ev(1,i_ev)=iv ! vibrational qn
      qn_ev(2,i_ev)=i  ! partial wave qn (lm combined)
      qn_ev(3:5,i_ev)=qnums_Q(1:3,1,i)  ! electronic state e, partial wave l, partial wave projection m
      print *, "DEBUG:", iv, i, qnums_Q(1:3,1,i)
      qn_map(qn_ev(1,i_ev),qn_ev(3,i_ev),qn_ev(4,i_ev),qn_ev(5,i_ev))=i_ev ! 1st index - iv, 2-electronic, 3-l, 4-m
      energies_ev(i_ev)=energies_v(iv) ! electronic energies are not yet added!!!
    Enddo
  Enddo
  
  ! S-matrix, S_ev
  allocate(S_ev(num_ev,num_ev,num_scatE))
  S_ev=(0.d0,0.d0)
  Do ie=1,num_scatE
    Do i=1,num_ev
      Do j=1,num_ev
        Do i_Q=1,num_Q
          wfi=wf_on_geom(qn_ev(1,i),i_Q)
          wfj=wf_on_geom(qn_ev(1,j),i_Q)
          i_e=qn_ev(2,i)
          j_e=qn_ev(2,j)
          S_ev(i,j,ie)=S_ev(i,j,ie)+conjg(wfj)*S_Q(i_e,j_e,i_Q,ie)*wfi*dQ(i_Q)
!          if(ie==49 .and. i==11 .and. j==11)Print *,'kuku',conjg(wfj),S_Q(i_e,j_e,i_Q,ie),wfi,dQ(i_Q)
        Enddo
      Enddo
    Enddo
!    call K_S(K_ev(1:num_ev,1:num_ev,ie),S_ev(1:num_ev,1:num_ev,ie),num_ev)
    
    Do i=1,num_ev
      If(ie==100 )Write(39,'(100e12.4)')sum(abs(S_ev(i,1:num_ev,ie)**2)),abs(S_ev(i,:,ie))
    Enddo
  Enddo

  
End Subroutine vibr_FT


! **************  Integrated elastic  ******************************

Subroutine Calc_integral_XS!(E,xs)
  Use global_params
  Integer l,lp,mu,mu2,mup,mu2p,J,iv,ivp,el,elp,ip2,i2,ip,i,i_ener,lambda,ji,jp,lam,lamp
  Real*8 Cleb,E,tmp,xs(0:20,0:20,num_scatE),xs_tot(0:20,num_scatE),delt  !xs(num_v,num_v,num_scatE)
  Complex*16 A2
  Complex*16, allocatable, dimension(:,:,:,:,:) :: A
  Complex*16, allocatable, dimension(:,:,:,:) :: Aj
  character*2 cex2

  iv=1;ivp=1;el=1;elp=1

! --------- averaged over random orientations of the target  ---------

  Allocate(A(0:2*l_max,-2*l_max:2*l_max,0:l_max,0:l_max,num_scatE))
  xs=0.d0;A=0d0
  Do l=0,l_max; Do lp=0,l_max; Do mu=-l,l; Do mup=-lp,lp;  Do J=abs(l-lp),l+lp
    ip=qn_map(ivp,elp,lp,mup);
    i=qn_map(iv,el,l,mu);
    If(ip*i ==0) stop 'ip*i=0'
    Do i_ener=1,num_scatE
      A(J,mu-mup,l,lp,i_ener)=A(J,mu-mup,l,lp,i_ener)+Cleb(2*J,2*(mu-mup),2*lp,-2*mup,2*l,2*mu)*(S_ev(ip,i,i_ener)-delt(ip,i))
    Enddo;
  Enddo;Enddo;Enddo;Enddo;Enddo;

  Do l=0,l_max; Do lp=0,l_max;Do J=abs(l-lp),l+lp; Do lambda=-J,J
  Do i_ener=1,num_scatE
    xs(1,1,i_ener)=xs(1,1,i_ener)+abs(A(J,lambda,l,lp,i_ener))**2
  Enddo
  Enddo;Enddo;Enddo;Enddo;

  Open(58,file='cs_elastic_averaged_orientation.dat')
  write(58,*)'# energy (eV), cs (Ang^2)'
  Do i_ener=1,num_scatE
    xs(1,1,i_ener)=xs(1,1,i_ener)*pi/(2.*E_el_Rmat(i_ener))
    write(58,'(10e20.12)')E_el_Rmat(i_ener)*au_eV,xs(1,1,i_ener)*(au_cm*1.d8)**2
  Enddo
  Close(58)
  deallocate(A)

  ! --------- the target is in j state ---------
  ji=0;lam=0;lamp=0 ! initial (ji,lam) and final (jp,lamp) rotational states of the target
  Allocate(Aj(0:ji+2*l_max,0:l_max,0:l_max,num_scatE))
  xs=0.d0;
  Do jp=max(0,ji-4),ji+4
    Aj=0.d0
!    Do l=0,l_max; Do lp=0,l_max; Do J=0,lp+l; Do mu=-l,l; Do mup=-lp,lp;
    Do l=0,l_max; Do lp=0,l_max; Do J=max(abs(ji-l),abs(jp-lp)),min(ji+l,jp+lp); Do mu=-l,l; Do mup=-lp,lp;
      ip=qn_map(ivp,elp,lp,mup);
      i=qn_map(iv,el,l,mu);
      If(ip*i ==0) stop 'ip*i=0'
      If(lamp+mup==lam+mu .and. mup==mu)then
      Do i_ener=1,num_scatE
          Aj(J,l,lp,i_ener)=Aj(J,l,lp,i_ener)+Cleb(2*J,2*(mup+lamp),2*lp,2*mup,2*jp,2*lamp)*Cleb(2*J,2*(mu+lam),2*l,2*mu,2*ji,2*lam)*(S_ev(ip,i,i_ener)-delt(ip,i))
        Enddo;
      endif
    Enddo;Enddo;Enddo;Enddo;Enddo;

!    Do l=0,l_max; Do lp=0,l_max;Do J=0,lp+l
    Do l=0,l_max; Do lp=0,l_max;Do J=max(abs(ji-l),abs(jp-lp)),min(ji+l,jp+lp)
    Do i_ener=1,num_scatE
      xs(jp,ji,i_ener)=xs(jp,ji,i_ener)+abs(Aj(J,l,lp,i_ener))**2 /(2.*J+1.)
    Enddo
    Enddo;Enddo;Enddo
    xs(jp,ji,:)=xs(jp,ji,:)*(2.*jp+1.d0)
  Enddo

! adjust the final j threshold energy!!
  Open(58,file='cs_j='//cex2(ji)//'.dat')
  write(58,*)'# energy (eV), cs (Ang^2)'
  Do i_ener=1,num_scatE
    xs(:,ji,i_ener)=xs(:,ji,i_ener)*pi/(2.*E_el_Rmat(i_ener))
    xs_tot(ji,i_ener)=sum(xs(:,ji,i_ener))
    write(58,'(100e20.12)')E_el_Rmat(i_ener)*au_eV,xs(max(0,ji-4):ji+4,ji,i_ener)*(au_cm*1.d8)**2,xs_tot(ji,i_ener)*(au_cm*1.d8)**2
  Enddo
  Close(58)
  deallocate(Aj)

! ! --------- the target is in the j=0 state ---------
! ! it does not work correctly (yet)
!   xs=0.d0
!   Do i_ener=1,num_scatE
!     Do l=0,l_max;
!       A2=0.d0
!       Do mu=-l,l
!         ip=qn_map(ivp,elp,l,mu);
!         i=qn_map(iv,el,l,mu);
!         If(ip*i ==0) stop 'iip*i=0'
!         A2=A2+(S_ev(ip,i,i_ener)-delt(ip,i))
!       Enddo
!       xs(1,1,i_ener)=xs(1,1,i_ener)+A2*conjg(A2)
!     Enddo
!   Enddo
!   Open(58,file='cs_elastic_j0.dat')
!   write(58,*)'# energy (eV), cs (Ang^2)'
!   Do i_ener=1,num_scatE
!     xs(1,1,i_ener)=xs(1,1,i_ener)*pi/(2.*E_el_Rmat(i_ener))
!     write(58,'(10e20.12)')E_el_Rmat(i_ener)*au_eV,xs(1,1,i_ener)*(au_cm*1.d8)**2
!   Enddo
!   Close(58)



End Subroutine Calc_integral_XS

! **************  Differential elastic  ******************************

Subroutine Calc_differential_XS!(E,xs)
  Use global_params
  Implicit None
  Integer l,lp,mu,mu2,mup,mu2p,J,iv,ivp,el,elp,ip2,i2,ip,i,i_ener,lambda,ji,jp,lam,lamp,&
     i_theta,m,mp,np_theta,ne_dcs,i_tmp(1),ind2plot(100)
  Real*8 Cleb,E,tmp,xs(0:20,0:20,num_scatE),delt,pm(0:10),x,sums(-l_max:l_max,0:l_max),&
      sum2,xs_av(num_scatE),theta_func(0:l_max),energies_to_plot_dcs(100)
  Complex*16 mfactor
  Complex*16, allocatable, dimension(:,:,:,:,:) :: A,BJLtilde
  Real*8, allocatable, dimension(:) :: theta_grid
  Complex*16, allocatable, dimension(:,:,:) :: thetalm
  Real*8, allocatable, dimension(:,:) :: dxs
  character*2 cex2

  iv=1;ivp=1;el=1;elp=1

! --------- averaged over random orientations of the target  ---------

  Allocate(A(0:2*l_max,-2*l_max:2*l_max,0:l_max,0:l_max,num_scatE))
  xs=0.d0;A=0.d0
  Do l=0,l_max; Do lp=0,l_max; Do mu=-l,l; Do mup=-lp,lp;  Do J=abs(l-lp),l+lp
    ip=qn_map(ivp,elp,lp,mup);
    i=qn_map(iv,el,l,mu);
    If(ip*i ==0) stop 'ip*i=0'
    Do i_ener=1,num_scatE
      A(J,mu-mup,lp,l,i_ener)=A(J,mu-mup,lp,l,i_ener)+Cleb(2*J,2*(mu-mup),2*lp,-2*mup,2*l,2*mu)*(S_ev(ip,i,i_ener)-delt(ip,i))
    Enddo;
  Enddo;Enddo;Enddo;Enddo;Enddo;

! integrated
!  Do l=0,0; Do lp=0,0;Do J=abs(l-lp),l+lp; Do lambda=-J,J
  Do l=0,l_max; Do lp=0,l_max;Do J=abs(l-lp),l+lp; Do lambda=-J,J
  Do i_ener=1,num_scatE
    xs(1,1,i_ener)=xs(1,1,i_ener)+abs(A(J,lambda,lp,l,i_ener))**2
  Enddo
  Enddo;Enddo;Enddo;Enddo;
  Do i_ener=1,num_scatE
    xs(1,1,i_ener)=xs(1,1,i_ener)*pi/(2.*E_el_Rmat(i_ener))
  Enddo

! !  check of normalization of associated Legendre polynomials
!    np_theta=100;sum2=0.d0
!    Do i=1,np_theta
!      x=-1.d0+2.*(i-1)/np_theta
!      CALL dASLGF(2,x,0,l_max,pm(0:l_max))
! !     !cds.cern.ch/record/2050838/files/c330.pdf
!      sum2=sum2+pm(0)**2
!    Enddo
!    print *,sum2*2.d0/np_theta
! !  call lpmn (1, 1, 1, 0.121d0, pm, pd )
! !  call lpmns (2, 1, 0.121d0, pm,pd );print *,pm(0:1)


! differential
  np_theta=200
  allocate(BJLtilde(0:2*l_max,-2*l_max:2*l_max,-l_max:l_max,np_theta,num_scatE),&
    thetalm(0:l_max,-l_max:l_max,np_theta),theta_grid(np_theta),dxs(np_theta,num_scatE))


  sums=0.d0
  Do i_theta=1,np_theta
    theta_grid(i_theta)=-1.d0+2.d0*(i_theta-1)/(np_theta-1)
    Do m=-l_max,l_max
      CALL dASLGF(2,theta_grid(i_theta),m,l_max,theta_func(0:l_max))
      Do l=0,l_max
        thetalm(l,m,i_theta)=theta_func(l)* ci**l
        if(m>0 .and. mod(m,2)==1)thetalm(l,m,i_theta)=-thetalm(l,m,i_theta)
      Enddo
      Do l=0,l_max
        sums(m,l)=sums(m,l)+abs(thetalm(l,m,i_theta))**2
      Enddo
    Enddo
  Enddo
  Print *,'checking normalization of functions Theta(x)',sums(1,:)*2.d0/(np_theta-1)
!  thetalm=thetalm*sqrt(2.d0/np_theta)

  Print *,'calculating BJLtilde and diff xs...'
  BJLtilde=0.d0
  dxs=0.d0
  Do i_ener=1,num_scatE
    Do l=0,l_max;Do lp=0,l_max; Do J=abs(l-lp),l+lp;Do Lam=-J,J;Do mp=-lp,lp
      mfactor=sqrt(2.*l+1.d0)*Cleb(2*J,-2*mp,2*lp,-2*mp,2*l,0)*A(J,Lam,lp,l,i_ener)
      BJLtilde(J,Lam,mp,:,i_ener)=BJLtilde(J,Lam,mp,:,i_ener)+thetalm(lp,mp,:)*mfactor
!      if(i_ener==1)print *,thetalm(lp,mp,1),mfactor,A(J,Lam,lp,l,i_ener)
    Enddo; Enddo;Enddo;Enddo;Enddo

    Do J=0,2*l_max;Do Lam=-J,J;Do mp=-l_max,l_max
      dxs(:,i_ener)=dxs(:,i_ener)+1.d0/(2*J+1.d0)*abs(BJLtilde(J,Lam,mp,:,i_ener))**2
    Enddo;Enddo;Enddo

    dxs(:,i_ener)=dxs(:,i_ener)*pi/(2.*E_el_Rmat(i_ener))
    xs_av(i_ener)=sum(dxs(:,i_ener))! integrated cross section

  Enddo
  dxs=dxs/(2.*pi)! averading over phi
  xs_av=xs_av*2.d0/(np_theta-1)

  Print *,'finished calculating BJLtilde and diff xs !'

! Plotting Differential cross section for chosen energies
  ne_dcs=1
  !energies_to_plot_dcs(1)=1
  !energies_to_plot_dcs(2)=1.5
  !energies_to_plot_dcs(3)=2
  !energies_to_plot_dcs(4)=2.5
  !energies_to_plot_dcs(5)=3
  energies_to_plot_dcs(1)=5
  !energies_to_plot_dcs(7)=7
  energies_to_plot_dcs=energies_to_plot_dcs/au_eV
  Do i=1,ne_dcs
    i_tmp=minloc(abs(energies_to_plot_dcs(i)- E_el_Rmat(1:num_scatE)))
    ind2plot(i)=i_tmp(1)
  Enddo
  Open(58,file='cs_diff_elastic_averaged_orientation.dat')
  write(58,'(A12,200f12.4)')'# energy(eV)=', E_el_Rmat(ind2plot(1:ne_dcs))*au_eV
  write(58,'(A)')'# angle(deg.), dcs (Ang^2)/srad'
  Do i_theta=1,np_theta
    write(58,'(200e12.4)')acos(theta_grid(i_theta))*180./pi,(dxs(i_theta,ind2plot(i))*(au_cm*1.d8)**2,i=1,ne_dcs)
  Enddo
  Close(58)



  Open(58,file='cs_integrated_averaged_orientation.dat')
  Do i_ener=1,num_scatE
    write(58,'(10e20.12)')E_el_Rmat(i_ener)*au_eV,xs_av(i_ener)*(au_cm*1.d8)**2,xs(1,1,i_ener)*(au_cm*1.d8)**2
  Enddo
  Close(58)

  ip=qn_map(1,1,0,0);
  i =qn_map(1,1,0,0);
  Print *,'checking T matrix element, |T00|^2=',abs(S_ev(i,ip,1)-delt(ip,i))**2
  Print *,'checking A matrix element, |A00|^2=',abs(A(0,0,0,0,1) )**2
  Print *,'checking B matrix element, 2*|B00|^2=',2*abs(BJLtilde(0,0,0,1,1) )**2

  deallocate(A,BJLtilde,thetalm,theta_grid,dxs)

End Subroutine Calc_differential_XS

! ****************************************************************
!  *****      MDQT staff    ***********

! ****************************************************************
 Subroutine Calc_T_phys(N,n_o,beta,S,T_phys)
   Integer N,n_o,i,n_c,j,INFO,IPIV(N)
   Complex*16 S(N,N),T_phys(n_o,n_o),ci,beta(N),tmpc
   Complex*16, allocatable :: Scc(:,:),Sco(:,:),Soc(:,:),Soo(:,:),Stmp(:,:)

   ci=(0.d0,1.d0)
   n_c=N-n_o
   T_phys=(0.d0,0.d0)
   If(n_c==0)Then
     T_phys=S
     return
   Endif
   Allocate(Scc(n_c,n_c),Sco(n_c,n_o),Soc(n_o,n_c),Soo(n_o,n_o),Stmp(n_o,n_o))
   Scc=S(n_o+1:n,n_o+1:n)
   Soc=S(1:n_o,n_o+1:n)
   Sco=S(n_o+1:n,1:n_o)
   Soo=S(1:n_o,1:n_o)
   Do i=1,n_c
     If(Abs(Imag(beta(i+n_o)))<100.)Then
       tmpc=beta(i+n_o)      
     Else
       tmpc=100. *beta(i+n_o)/abs(beta(i+n_o))    
     Endif
     Scc(i,i)=Scc(i,i)-exp(-2*ci*tmpc)
   Enddo
   CALL ZGESV(n_c,n_o,Scc,n_c,IPIV(1:n_c),Sco,n_c,INFO)
   If(info.ne.0)Print *,'info is not 0'
   Stmp=MatMul(Soc,Sco)
   T_phys(1:n_o,1:n_o)=Soo-Stmp

   Do i=1,n_o
     T_phys(i,i)=T_phys(i,i)-1.d0
   Enddo
   Deallocate(Scc,Sco,Soc,Soo,Stmp)
 End Subroutine Calc_T_phys
! --------------------------------------
 Subroutine Calc_K_phys(N,n_o,beta,K,K_phys)
   Integer N,n_o,i,n_c,j,INFO,IPIV(N)
   Real*8 beta(N)
   Complex*16 K(N,N),K_phys(n_o,n_o),ci
   Complex*16, allocatable :: Kcc(:,:),Kco(:,:),Koc(:,:),Koo(:,:),Ktmp(:,:)

   ci=(0.d0,1.d0)
   n_c=N-n_o
   If(n_c==0)Then
     K_phys=K
     return
   Endif
   Allocate(Kcc(n_c,n_c),Kco(n_c,n_o),Koc(n_o,n_c),Koo(n_o,n_o),Ktmp(n_o,n_o))
   Kcc=K(n_o+1:n,n_o+1:n)
   Koc=K(1:n_o,n_o+1:n)
   Kco=K(n_o+1:n,1:n_o)
   Koo=K(1:n_o,1:n_o)
   Do i=1,n_c
     Kcc(i,i)=Kcc(i,i)+tan(beta(i+n_o))
   Enddo
   CALL ZGESV(n_c,n_o,Kcc,n_c,IPIV(1:n_c),Kco,n_c,INFO)
   Ktmp=MatMul(Koc,Kco)
   K_phys(1:n_o,1:n_o)=Koo-Ktmp

   Deallocate(Kcc,Kco,Koc,Koo,Ktmp)
 End Subroutine Calc_K_phys
! ****************************************************************
 Subroutine K_S(K,S,N)
   Integer i,INFO,N,IPIV(N)
   Complex*16 K(N,N),S(N,N),K2(N,N),K1(N,N),ci
   ci=(0.d0,1.d0)
   K2=ci*K
   K1=-1.d0*K2
   Do i=1,N
     K2(i,i)=K2(i,i)+1.d0
     K1(i,i)=K1(i,i)+1.d0
   Enddo
!  Inversion and Multiplication
   K1=Transpose(K1); K2=Transpose(K2)
   CALL ZGESV(N,N,K1,N,IPIV,K2,N,INFO)
   S=Transpose(K2)
 End Subroutine K_S
! ****************************************************************
 Integer Function n_o_deter(E1,ns,Estates)
   Integer n_o,i,ns
   Real*8 E1,Estates(ns)
   n_o=ns
   Do i=1,ns
     If(E1<Estates(i))Then
       n_o=i-1
       Exit
     Endif
   Enddo
   n_o_deter=n_o
 End Function n_o_deter
! ****************************************************************

!  *****     reading_R_matrix_data    ***********

! ****************************************************************
Subroutine reading_R_matrix_data
  Use global_params
  implicit none
  integer :: i, ie, j, j_p, k, l, m, l_p, my_count, a, b, c, i_name,j2,i2,max_dim,n_num,&
     itmp(1:4), dims_extended(num_gamma_Q),i_rec,records(5,10000),num_recs,i_Q,num_ener(100),&
     ordered_geom(100),num_folders,i_Qlast,i_folders,i_Q2,i_Qadd,geom_file(100)
  real(kind=8) :: tmp,E
  real(kind=8), allocatable, dimension(:,:,:) :: ener_ch_lm
  real(kind=8), allocatable, dimension(:) :: temp_arr
  Integer, allocatable, dimension(:,:,:,:) :: C2v_Cinf
  complex(kind=8), allocatable, dimension(:,:) :: k_mtrx,s_mtrx
  integer, dimension(num_gamma_Q) :: md = (/6,1,3,3,3,3,3,3/)
  character*11, dimension(num_gamma_Q) :: NoF = (/'doublet.Ag ','doublet.Au ',&
                    'doublet.B1g','doublet.B1u','doublet.B2g','doublet.B2u','doublet.B3g','doublet.B3u' /)!UKRMol
!QN  character*4, dimension(num_gamma_Q) :: NoF = (/'2Ag ','2Au ','2B1g','2B1u','2B2g','2B2u','2B3g','2B3u' /)
!  integer, dimension(num_gamma_Q) :: md = (/9,4,6,6 /)
  character(len=15), dimension(num_gamma_Q)  :: name_of_file
  character(len=100) :: name_of_file2
  character*2 cex2
  
  max_dim=maxval(md)
  num_elec=1  !assuming that there is no excited electronic states
  dim_lm=num_elec*(l_max+1)**2 ! dimension of the S_Q matrix
  
  num_scatE = 2000
  num_ener=num_scatE! number of energies for each i_Q 
  
  allocate(geom(1000))

  num_folders=1
  i_Qlast=0;i_Qadd=0
  Do i_folders=1,num_folders
    open(unit = 7, file= './f'//cex2(i_folders)//'/geometries', action='read')
    read(7,*)
    Do i_Q=1,1000
      read(7,*,end=2)j,tmp
      If(tmp>0.1)then
        i_Qlast=i_Qlast+1
        geom_file(i_Qlast)=j
        geom(i_Qlast)=tmp
      Else
        i_Qadd=1! if the first geometry is 0
      Endif
      print *,'geometry is',tmp
    Enddo
2   continue
  Enddo; i_folders=1  !!!
  num_Q=i_Qlast;print *,num_Q;

  allocate(E_el_Rmat(num_scatE),S_Q(dim_lm,dim_lm,num_Q,num_scatE),C2v_Cinf(1000,num_gamma_Q,3,num_Q),&
    ener_ch_lm(1000,num_gamma_Q,num_Q),qnums_Q(3,num_Q,dim_lm))


  !  ordering geometries
  Do i=1,num_Q
    ordered_geom(i)=i
  Enddo
  Do i=1,num_Q
    Do j=i+1,num_Q
      If(geom(i)>geom(j))Then
        tmp=geom(i)
        geom(i)=geom(j)
        geom(j)=tmp
        k=ordered_geom(i)
        ordered_geom(i)=ordered_geom(j)
        ordered_geom(j)=k
      Endif
    Enddo
  Enddo
!  geom(1)=1.2d0;geom(2)=1.5d0;geom(3)=1.8d0;
  S_Q=(0.d0,0.d0);C2v_Cinf=0


  Do i=1,dim_lm
    call i2lm(i,l,m)
    call lm2i(l,m,j)
    Print *,j,i,l,m
  Enddo
  
  geom_Q: Do i_Q=1,num_Q
  
!   reading files *.channels
!    name_of_file = (/ 'A1.channel', 'A2.channel', 'B1.channel', 'B2.channel' /)
    i_rec=0
    do i_name = 1, num_gamma_Q
!QN      name_of_file2=trim(NoF(i_name))//'.channel'
      i_Q2=geom_file(i_Q)
      print *,i_Q,geom_file(i_Q),geom(i_Q)
      If(i_Q2<10)then
         name_of_file2='channels.geom'//char(i_Q2+48)//'.'//trim(NoF(i_name))
      Else
         name_of_file2='channels.geom'//cex2(i_Q2)//'.'//trim(NoF(i_name))
      Endif
      print *, name_of_file2
!QN      open(unit = 7, file= './'//cex2(ordered_geom(i_Q))//'/matrices/'//name_of_file2, action='read')
!      print*,'./f'//cex2(i_folders)//'/collected_scattering_data/channels/'//name_of_file2
      open(unit = 7, file= './f'//cex2(i_folders)//'/collected_scattering_data/channels/'//name_of_file2, action='read')
      do j = 1, 2;  read(7,*) ; enddo !- ignore useless lines
      read(7,*)itmp(1:4)
      dims_extended(i_name)=itmp(4)
      do j = 1, itmp(1)+1;  read(7,*) ; enddo !- ignore useless lines

      do j = 1, dims_extended(i_name)
        i_rec=i_rec+1
        records(1,i_rec)=i_name
        read(7,*)records(2,i_rec),records(3,i_rec),records(4,i_rec),records(5,i_rec),ener_ch_lm(records(2,i_rec),i_name,i_Q)
!        Write(6,*)records(1:5,i_rec),ener_ch_lm(records(2,i_rec),i_name,i_Q)
        C2v_Cinf(records(2,i_rec),i_name,1:3,i_Q)=records(3:5,i_rec) ! i_el, l,lambda
      enddo
      Close(7)
    enddo
    num_recs=i_rec
    
!    name_of_file = (/ 'A1.kmat', 'A2.kmat', 'B1.kmat', 'B2.kmat' /)
    file_read:  do i_name = 1, num_gamma_Q
      !- Matrix allocation
      n_num=md(i_name)*(md(i_name)+1)/2 ! it works only in dimension does not change with energy
      allocate( temp_arr( n_num), k_mtrx(md(i_name),md(i_name)),s_mtrx(md(i_name),md(i_name)))
     
!QN      name_of_file2=trim(NoF(i_name))//'.kmat'
      If(i_Q2<10)then
         name_of_file2='K-matrix.geom'//char(i_Q2+48)//'.'//trim(NoF(i_name))
      Else
         name_of_file2='K-matrix.geom'//cex2(i_Q2)//'.'//trim(NoF(i_name))
      Endif
!      name_of_file2='K-matrix.geom1.'//trim(NoF(i_name))
      print *, name_of_file2
!QN      open(unit = 7, file= './'//cex2(ordered_geom(i_Q))//'/matrices/'//name_of_file2, action='read')
      open(unit = 7, file= './f'//cex2(i_folders)//'/collected_scattering_data/K-matrices/'//name_of_file2, action='read')
!      open(unit = 7, file= './'//cex2(ordered_geom(i_Q))//'/collected_scattering_data/K-matrices/'//name_of_file2, action='read')
!      open(unit = 7, file= '../HeHp/6311Gstar/'//cex2(ordered_geom(i_Q))//'/matrices/'//name_of_file2, action='read')
!QN      do j = 1, 5;  read(7,*) ; enddo !- ignore useless lines
      do j = 1, 6;  read(7,*) ; enddo !- ignore useless lines
      !- loop over energy
      energy : Do ie = 1, num_scatE
!        print *,ie
        read(7,*,end=1) a, b, c, E
        If(a.ne.md(i_name)) exit
        If(i_Q==1 .and. i_name==1)E_el_Rmat(ie)=E/2.d0
        !=====================================
        !- read from file and save in 1D array
        !=====================================
        do j = 1, n_num
          read(7,'(d20.13)',advance="NO")temp_arr(j)
          if(mod(j,4)==0) read(7,*) !- to go to the next line
        ! print *, "temp : ", j, temp_arr(j)
        enddo
   
        !=================================
        !- constructing K-matrix from temp
        !=================================
        my_count =0
        do i=1, md(i_name)    
          do j=1, i
            my_count = my_count + 1
            k_mtrx(i,j) = temp_arr(my_count)
            k_mtrx(j,i) = k_mtrx(i,j)
            ! write(*,'( 2d20.13)') k_mtrx(i,j)
          enddo
        enddo
        s_mtrx=(0.d0,0.d0)
        call K_S(k_mtrx(1:md(i_name),1:md(i_name)),s_mtrx(1:md(i_name),1:md(i_name)),md(i_name))
!         If(i_name==6)then
!           Do i=1,md(i_name)
!             write(26,'(100e12.4)')real(k_mtrx(i,1:md(i_name)))
!           Enddo
!           write(26,*)
!           Do i=1,md(i_name)
!             write(26,'(100e12.4)')s_mtrx(i,1:md(i_name))
!           Enddo
!           write(26,*)
!         Endif

        do i=1, md(i_name)    
          call lm2i(C2v_Cinf(i,i_name,2,i_Q),C2v_Cinf(i,i_name,3,i_Q),i2)
          qnums_Q(1:3,i_Q,i2)=C2v_Cinf(i,i_name,1:3,i_Q)
          do j=1,md(i_name)
            call lm2i(C2v_Cinf(j,i_name,2,i_Q),C2v_Cinf(j,i_name,3,i_Q),j2)
            If(i2<1 .or. i2>dim_lm .or. j2<1 .or. j2>dim_lm )Stop 'Problem with indexes!'
            S_Q(i2,j2,i_Q,ie)=s_mtrx(i,j)
          enddo
        enddo


!         If(ie==10 .and. i_Q==1 .and. i_name==num_gamma_Q)then
!           print *,dim_lm
!           Do i=1,dim_lm
!             Write(277,'(100e12.4)')sum(abs(S_Q(i,1:dim_lm,i_Q,ie))**2)
!           Enddo
!           Write(277,*)
!         Endif
      enddo energy
     
1     num_ener(i_Q)=min(num_ener(i_Q),ie-1)
!      Print *,'num_ener=',num_ener(i_Q)
      deallocate( temp_arr, k_mtrx,s_mtrx)
      close(7)
    enddo file_read
  
  Enddo geom_Q
!  Print *,num_ener(1:num_Q)
  num_scatE=minval(num_ener(1:num_Q))

! Lines below are to check continuity of the S-matrix with respect to energies and geometries
!   Open(27,file='Smatr_continuity_E.dat')
!   Do ie=1,num_scatE
!     Write(27,'(100e12.4)')E_el_Rmat(ie),S_Q(11,12,1:num_Q,ie)
!   Enddo
!   Close(27)
!   Open(27,file='Smatr_continuity_Q.dat')
!   j=num_scatE/10
!   Do i_Q=1,num_Q
!     Write(27,'(100e12.4)')geom(i_Q),(abs(S_Q(11,14,i_Q,i*j+1)),i=0,9)
!   Enddo
!   Close(27)
  el_energy_Q1=ener_ch_lm(1,1,1)

  Open(99,file='quantum_numbers')
  Do i2=1,dim_lm
    write(99,'(3I4)')qnums_Q(1:3,1,i2)
  enddo
  Close(99)
  deallocate(C2v_Cinf,ener_ch_lm)
end Subroutine reading_R_matrix_data
! ****************************************************************
Subroutine basis_change_lm
  Use global_params
  implicit none
  Integer i2,j2,ie,map_m(dim_lm),j,m
  Real*8 sqrt2,tmp
  Complex*16 U(dim_lm,dim_lm),matr_tmp(dim_lm,dim_lm)
  Do i2=1,dim_lm
    Write(276,'(100e12.4)')abs(S_Q(i2,1:dim_lm,1,1))!sum(abs(S_Q(i,1:dim_lm,i_Q,ie))**2)
  Enddo

  ! U is inially the identity matrix
  U=(0.d0,0.d0)
  Do i2=1,dim_lm
    U(i2,i2)=(1.d0,0.d0)
  Enddo
  sqrt2=sqrt(0.5d0)
! U is then modified
  Do i2=1,dim_lm
    If(qnums_Q(3,1,i2)>0)then
      Do j2=1,dim_lm
        If(qnums_Q(1,1,i2)==qnums_Q(1,1,j2) .and. qnums_Q(2,1,i2)==qnums_Q(2,1,j2) .and. qnums_Q(3,1,i2)==-qnums_Q(3,1,j2) )Exit
      Enddo
      If(j2>dim_lm)Stop 'problem with indexes in basis_change_lm'
      U(i2,i2)=sqrt2; U(i2,j2)=-sqrt2*ci
      U(j2,i2)=sqrt2; U(j2,j2)=sqrt2*ci
    Endif
  Enddo

  Do ie=1,num_scatE
    matr_tmp=matmul(U,S_Q(:,:,1,ie))
    S_Q(:,:,1,ie)=matmul(matr_tmp,conjg(Transpose(U)))
  Enddo

  ! making map of channels with the same projection m
  j2=0
  Do m=0,l_max
    Do j=-1,min(m,1),2
      Do i2=1,dim_lm
        if(qnums_Q(3,1,i2)==m*j)then
          j2=j2+1
          map_m(j2)=i2
        Endif
      Enddo
    Enddo
  Enddo

  tmp=0.
  Do i2=1,dim_lm
    Write(277,'(100e12.4)')abs(S_Q(map_m(i2),map_m(1:dim_lm),1,1))!sum(abs(S_Q(i,1:dim_lm,i_Q,ie))**2)
    Do j2=1,dim_lm
      if(qnums_Q(3,1,map_m(i2)) /= qnums_Q(3,1,map_m(j2)) )then
        tmp=max(tmp, abs(S_Q(map_m(i2),map_m(j2),1,1) ))
        S_Q(map_m(i2),map_m(j2),1,1)=0.d0
      Endif
    Enddo
  Enddo
  print *,'the largest S-matrix element between different m-blocks is',tmp
  If(tmp>0.1)stop

  Open(99,file='quantum_numbers_map')
  Do i2=1,dim_lm
    write(99,'(3I4)')qnums_Q(1:3,1,map_m(i2))
  enddo
  Close(99)
End Subroutine basis_change_lm
! ****************************************************************
function cex2(nj)
  character*2 cex2
  integer cnj,dnj,unj,nj
  cnj = nj/100
  dnj = (nj - cnj*100)/10
  unj = nj - cnj*100 - dnj*10
!  cex2 = char(cnj+48)//char(dnj+48)//char(unj+48)
  cex2 = char(dnj+48)//char(unj+48)
end function cex2!
!****************************************************************

Subroutine i2lm(i,l,m)
 Use global_params
 Integer i,l,m,j
 j=0
 Do m=-l_max,l_max;Do l=abs(m),l_max;
   j=j+1 
   if(i==j)return
 Enddo;enddo
 Print *,'in Subroutine i2lm i is too large, i=',i;stop
End Subroutine i2lm
!----------------------------------------------------
Subroutine lm2i(l,m,j)
 Use global_params
 Integer lp,mp,l,m,j
 j=0
 Do mp=-l_max,m;Do lp=abs(mp),l_max;
   j=j+1 
   if(mp==m .and. lp==l)return
 Enddo;enddo

 Print *,'in Subroutine lm2i i,j, or m is out of range l,m,j,i=',l,m,j;stop
End Subroutine lm2i
!----------------------------------------------------

include "Clebsch-Gordan_coefs.f90"
include "BSCuFGR_sub.f90"

