# Geometries can be specified either manually in the array 'geometries'
# by copying what is between start copy and end copy for each geometry
# or automatically as shown below the hash array %geometry
#
# Note that 'length_unit' should be set to the actual length unit used for values in 'atoms' array,
# later (in &generate_geometries) $model{'r_unit'} is set also to this unit for consistency reasons
#
# Note that there's a restriction on the orientation of the molecules in the scripts (although there isn't one in the codes themselves)
# Your molecular target should be oriented as follows for the corresponding point groups ('any orientation' still requires the axes to
# be along the cartesian axes):
# D2h: any orientation
# C2v: C2 axis along Z
# C2h: C2 axis along Z
# D2:  any orientation
# C2:  C2 axis along Z
# Cs:  Molecule in the YZ plane
# Ci:  any orientation
# C1:  any orientation

%geometry = (

  'suffix', "multi",   # string added to model directory to distinguish runs
                              # with different geometry settings

  'geometry_labels',  "   R     ",         # labels used on the first line of output files
                                          # it should correspond to numbers given in 'geometries'->'description'
  'correct_cm',   1,                      # correct the center of mass to be at the origin
  'length_unit',  0,                      # 0 - atomic units, 1 - Angstroms

  'geometries', [
    { 'description', sprintf("%8.5f", $R),
      'gnuplot_desc', "R = ".sprintf("%5.2f", $R), # used in gnuplot files for keys
       # specify ALL atoms (even redundant with respect to symmetry elements)
       'atoms', [ [ "N", 0.000000000000,     0.000000000000,     1.],
                  [ "N", 0.000000000000,     0.000000000000,    -.1] ]
     },
  ],

  # the following option can be used e.g. to continue an interupted run
  # all geometries are generated but codes will run only for specified geometries
  'start_at_geometry', 5,                # codes will run only for geometries with index >= than this number
  'stop_at_geometry',  0,               # this can be used to stop at certain geometry
                                         # if zero then codes will run for all geometries
);


# # -- internuclear distances split up into 3 sections
my $Ri = 1.9  ;
my $Rf = 2.3 ;
my $dR = 0.02 ;


# # -- before the targeted resonance
 for (my $R = $Ri; $R <= $Rf; $R += $dR) {
#   $dRN1 = ($R - $R0) * $N1Rfraction;
   $dRN1 = $R /2. ;
   $dRN2 = -$R /2. ;
   push(@{$geometry{'geometries'}},
        { 'description', sprintf("%8.5f", $R),
          'gnuplot_desc', "R = ".sprintf("%5.2f", $R), # used in gnuplot files for keys
          'atoms', [ [ "N", 0.0,  0.0,   $dRN1 ],
                     [ "N", 0.0,  0.0,   $dRN2 ] ]
        }
   );
 }
