# Settings related to a specific installation of UK R-matrix codes

# Path to executables can be spicified directly in %dirs or later if you are using several computers
# (see switch($run{'computer'}) below
# Use ${bs} (see dirfile.pm) in relative paths instead of \ or / for portability
# Some directories are determined later automatically
# If the full path must be used then it is not necessary to use ${bs}

%dirs = (

  'bin_in',    "/home/emol/UKRMol/ukrmol-in-3.2/build/bin",       # Directory where executables of UKRmol-in are
  'bin_out',   "/home/emol/UKRMol/ukrmol-out-3.2/build/bin",       # Directory where executables of UKRmol-out are
#  'molpro',    "/home/slava/soft/QNEE6.1/molpro/exe",  # Directory where executables of MOLPRO are
  'psi4',      "/usr/bin",  # Directory where executables of PSI4 are
  'molcas',    "",  # Directory where executables of MOLCAS are

  'basis',     "/home/emol/UKRMol/UKRmol-scripts-release-1.0/basis.sets",         # Directory where basis sets are - templates named 'swmol3.A.$basis' or 'molpro.A.$basis' where 'A' standfor an atom
  'templates', "/home/emol/UKRMol/UKRmol-scripts-release-1.0/input.templates",    # Directory where input templates are - read if 'use_templates' = 1
  'libs',      "/home/emol/UKRMol/UKRmol-scripts-release-1.0/lib",                                    # Directory where UKRmol-scripts libraries are (equivalent to perl -I<libs>, or use of PERL5LIB)

  'output',    "N2-tennyson-test2-continued",                                       # Main directory for output in the working directory

);
