! -----------------------------------------------------------
 Real*8 function delt(i,j)
   integer i,j
   delt=0.
   If(i.eq.j)delt=1.
 end function delt
! -----------------------------------------------------------
 Real*8 function factor_3j(j1,j2,ind)
   Implicit None
   Integer j1,j2,ind
   Real*8 Cleb,Neg
   factor_3j=sqrt((2.d0*j1+1.d0)/(2.d0*j2+1.d0))*(Cleb(2*j2,0,2,0,2*j1,0))**2
   If(ind==0)factor_3j=1.d0
 end function factor_3j
! ****************************************************************
!     Function for calculation of Clebsch-Gordan coefs.
!     Using the formula (3) on page 238 by Varshalovich
!     Argument of function are integer number.
!     They are twice actual momenta and projections
      Real*8 Function Cleb(iL,iMM,il1,im1,il2,im2)
        Implicit None
        Integer iL,iMM,il1,im1,il2,im2,z1,z2,z
        Real*8 c,s,L,MM,l1,m1,l2,m2,Fac,Cle,Neg
        L=iL/2.d0; MM=iMM/2.d0; l1=il1/2.d0; m1=im1/2.d0; l2=il2/2.d0; m2=im2/2.d0;Cle=0.d0
        If ( (im1+im2==iMM).and.(Abs(im1).le.il1).and. (Abs(im2).le.il2).and.(Abs(iMM).le.iL) .and.(iL.le.(il1+il2)).and.&
             (iL.ge.Abs(il1-il2)) )Then
          c =Sqrt(Fac(l1+l2-L)*Fac(l1-l2+L)*Fac(L+l2-l1)   /Fac(l1+l2+L+1))
          c =c*Sqrt(Fac(m1+l1)*Fac(l1-m1)*Fac(m2+l2)*Fac(l2-m2)   *Fac(MM+L)*Fac(L-MM)*(2.d0*L+1.))
          z1=Min(NInt(l1-m1),NInt(l1+l2-L),NInt(m2+l2))
          z2=Max(NInt(l2-L-m1),NInt(l1+m2-L),0)
          s =0.d0
          Do z =z2,z1
            s =s+Neg(z)/(Fac(z*1.d0)*Fac(l1+l2-L-z)*Fac(l1-m1-z) *Fac(l2+m2-z)*Fac(L-l2+m1+z)*Fac(L-l1-m2+z))
          EndDo
          s =s*c
          Cle=s
        Else
          Cle=0.d0
        EndIf
        If(abs(Cle)<1.e-12)Cle=0.d0
        Cleb=Cle
      End Function Cleb
! *****************************************************
 Real*8 Function Neg(j)
   Integer j
   Neg=1.d0
   If(mod(Abs(j),2)==1)Neg=-1.d0
 End Function Neg
!procedures Fac =x!
 Real*8 Function Fac(x)
   Integer i
   Real*8 x,y
   y=1.0
   Do i=1,NInt(x)
     y=y*i
   EndDo
   Fac=y
 End Function Fac
! *********************************************************
 Real*8 function delta_cron(i,j)
          integer i,j
          delta_cron=0.
          If(i.eq.j)delta_cron=1.
 end function delta_cron

! ****************************************************************
